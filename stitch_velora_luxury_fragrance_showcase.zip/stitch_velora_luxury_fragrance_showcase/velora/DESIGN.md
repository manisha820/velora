---
name: Velora
colors:
  surface: '#16130b'
  surface-dim: '#16130b'
  surface-bright: '#3d392f'
  surface-container-lowest: '#110e07'
  surface-container-low: '#1f1b13'
  surface-container: '#231f17'
  surface-container-high: '#2d2a21'
  surface-container-highest: '#38342b'
  on-surface: '#eae1d4'
  on-surface-variant: '#d0c5af'
  inverse-surface: '#eae1d4'
  inverse-on-surface: '#343027'
  outline: '#99907c'
  outline-variant: '#4d4635'
  surface-tint: '#e9c349'
  primary: '#f2ca50'
  on-primary: '#3c2f00'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#735c00'
  secondary: '#c9c6c5'
  on-secondary: '#313030'
  secondary-container: '#4a4949'
  on-secondary-container: '#bab8b7'
  tertiary: '#cecece'
  on-tertiary: '#2f3131'
  tertiary-container: '#b2b3b3'
  on-tertiary-container: '#444546'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c9c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474646'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c6'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#16130b'
  on-background: '#eae1d4'
  surface-variant: '#38342b'
typography:
  display-lg:
    fontFamily: Bodoni Moda
    fontSize: 80px
    fontWeight: '400'
    lineHeight: 90px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Bodoni Moda
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 56px
  headline-lg-mobile:
    fontFamily: Bodoni Moda
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
  headline-md:
    fontFamily: Bodoni Moda
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 40px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '300'
    lineHeight: 28px
    letterSpacing: 0.01em
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.2em
spacing:
  margin-mobile: 24px
  margin-desktop: 80px
  gutter: 24px
  section-gap: 160px
  unit: 8px
---

## Brand & Style

The design system embodies a cinematic, editorial aesthetic tailored for the high-end luxury fragrance market. It evokes a sense of timelessness, mystery, and exclusivity. The visual narrative centers on "The Art of Scent," treating every product as a masterpiece within a gallery.

The style is a blend of **Minimalism** and **High-Contrast Editorial**. It utilizes expansive white space (or "dark space") to create a breathing room that mimics the silence of a high-end boutique. Visual weight is carried by premium, large-scale photography with dramatic lighting and shallow depth of field. UI elements are architectural—thin lines, precise alignment, and sharp edges—ensuring the interface never distracts from the sensory allure of the product photography.

## Colors

The palette is rooted in a "Deep Onyx" (#0A0A0A) background to provide a cinematic foundation. Gold (#D4AF37) serves as the primary signature color, used sparingly for interactive highlights and branding to maintain its perceived value.

The system utilizes "Collection Identities" to theme the UI based on the fragrance currently being viewed:
- **Core:** Deep black backgrounds with gold typography and hairline platinum borders.
- **Pour Femme:** Soft blush accents with champagne gold.
- **Imperial:** Deep amber tones with burnished copper/gold.
- **Nocturne:** Midnight blue depths with cool silver metallic accents.
- **Éternité:** Pure, stark white surfaces with polished platinum details (switching to a light-mode variation).

## Typography

Typography follows an editorial hierarchy. **Bodoni Moda** provides high-contrast serifs that feel like a high-fashion magazine, used for all major headlines and product names. It should be typeset with generous leading and occasionally negative letter-spacing for large displays.

**Hanken Grotesk** is used for body copy and technical details to provide a clean, modern counterpoint. For labels, navigation, and secondary CTAs, use the `label-caps` style; the wide letter-spacing is essential to maintaining the luxury feel. All body text should prioritize legibility and be set in a "Light" or "Regular" weight to avoid visual clutter.

## Layout & Spacing

This design system uses a **Fixed Grid** model for content containers, set against a fluid background. On desktop, a 12-column grid is used with expansive 80px side margins. The defining characteristic is "Aggressive Whitespace"—vertical gaps between sections (section-gap) are significantly larger than standard web patterns to force focus on one story or product at a time.

- **Desktop:** 12 columns, 80px margins, 24px gutters. Content max-width: 1440px.
- **Tablet:** 8 columns, 40px margins, 20px gutters.
- **Mobile:** 4 columns, 24px margins, 16px gutters.

Alignment should be primarily asymmetrical for editorial sections (e.g., text blocks offset from images) and strictly centered for product discovery and checkout to ensure a sense of order and prestige.

## Elevation & Depth

To maintain a "flat luxury" aesthetic, traditional heavy shadows are avoided. Instead, depth is created through:
- **Tonal Layering:** Using different shades of black (e.g., #0A0A0A for backgrounds vs. #141414 for cards).
- **Hairline Outlines:** 1px borders in low-opacity Gold or Silver are used to define containers.
- **Glassmorphism:** Navigation bars and modal overlays use a high-density background blur (30px) with a 10% opacity white or black tint, mimicking frosted glass perfume bottles.
- **Parallax:** Subtle scroll-triggered movement of background images creates a sense of physical space and "cinematic" immersion.

## Shapes

The shape language is **Sharp (0)**. Perfect 90-degree angles are used for all buttons, input fields, and containers. This architectural rigidity reflects the precision of glass bottle manufacturing and the uncompromising nature of high luxury. 

Occasional use of perfect circles is permitted only for "Note" icons (scent profiles) or functional circular toggles to contrast the dominant rectangular grid.

## Components

### Buttons
Primary buttons are "Ghost" style: sharp corners, 1px gold border, and `label-caps` typography. On hover, they fill with solid gold and transition text to black. Secondary buttons are text-only with a 1px underline that expands from the center on hover.

### Cards
Product cards should have no visible borders or shadows. The product image should be silhouetted against a slightly lighter neutral background. Details (name and price) appear in centered typography beneath the image.

### Input Fields
Inputs are minimal: a single bottom-border line (1px). The label sits above in `label-caps`. Focus state changes the bottom border to Gold.

### Chips/Tags
Used for fragrance notes (e.g., "Oud," "Bergamot"). These are small, sharp-edged rectangles with a tonal background (e.g., 10% white on black) and no border.

### Scent Profile Map
A custom component featuring an abstract, radial diagram showing the balance of Top, Heart, and Base notes, utilizing the collection's specific metallic accent color.